#!/usr/bin/python3.8
import json
import logging
from datetime import date

from gspread import CellNotFound
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackQueryHandler, ConversationHandler

from difflib import get_close_matches
import shlex

import gspread
from oauth2client.service_account import ServiceAccountCredentials

scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']

creds = ServiceAccountCredentials.from_json_keyfile_name('creds.json', scope)
client = gspread.authorize(creds)

token1 = '1883945449:AAGXxMXsgYOUciS9siUC4Wzz68AdGMfHTqs'


def start(update, context):
    context.bot.send_message(chat_id=update.effective_chat.id, text="Bienvenue chez toi Ambroise :)")


CHANGE_SCORE = 1
CHANGE_NOTE = 2
ADD_MEETING = 3
GET_GOOD_NAME = 4


def get_main_keyboard(infos):
    keyboard = [[InlineKeyboardButton("Changer le score",
                                      callback_data=json.dumps({"a": CHANGE_SCORE, "d": {"id_contact": infos[0]}})),
                 InlineKeyboardButton("Modifier la note",
                                      switch_inline_query_current_chat="/note " + infos[0] + " \"<Rentre la note ici>\"")],

                [InlineKeyboardButton("Ajouter rencontre",
                                      callback_data=json.dumps({"a": ADD_MEETING, "d": {"id_contact": infos[0]}}))]]
    return InlineKeyboardMarkup(keyboard)


def get_entry(update, context):
    # print(update.message.chat)
    # print(update.message.from_user)
    print('###############################################################################################')
    if not (is_allowed_user(update.message.from_user.username)):
        context.bot.send_message(chat_id=update.effective_chat.id,
                                 text='Who the hell are you @' + str(update.message.from_user.username) + ' ?')
        return
    search = ' '.join(context.args[:2])

    search_this_name(update, context, search)


def search_this_name(update, context, search):
    infos, err = get_info_people(search)
    if err is not None:
        closes = find_close_names(search)
        if len(closes) > 0:
            keyboard = [[]]
            for name in closes[:4]:
                keyboard[0].append(
                    InlineKeyboardButton(name, callback_data=json.dumps({"a": GET_GOOD_NAME, "d": {"good_name": name}}))
                )
            context.bot.send_message(chat_id=update.effective_chat.id, text="Je n'ai rien trouve, vous voulez dire :",
                                     reply_markup=InlineKeyboardMarkup(keyboard))
            return
        else:
            context.bot.send_message(chat_id=update.effective_chat.id, text=err)
        return
    reply_with_infos(update, context, infos)


def find_close_names(search):
    sheet = client.open_by_key(get_id_sheet()).sheet1
    return get_close_matches(search, sheet.col_values(3))


def reply_with_infos(update, context, infos):
    if len(infos) >= 29 and infos[28] != '':
        context.bot.send_photo(chat_id=update.effective_chat.id, caption=beautify_infos(infos),
                               parse_mode=ParseMode.MARKDOWN, reply_markup=get_main_keyboard(infos),
                               photo=get_profile_picture_twitter_url(infos[28]))
    else:
        context.bot.send_message(chat_id=update.effective_chat.id, text=beautify_infos(infos),
                                 parse_mode=ParseMode.MARKDOWN, reply_markup=get_main_keyboard(infos))


def button(update, context):
    query = update.callback_query

    # CallbackQueries need to be answered, even if no notification to the user is needed
    # Some clients may have trouble otherwise. See https://core.telegram.org/bots/api#callbackquery
    query.answer()

    query = json.loads(query.data)
    action = query['a']
    datas = query['d']

    if action == CHANGE_SCORE:
        change_score(update, context, datas)
    if action == ADD_MEETING:
        add_meeting(update, context, datas["id_contact"])
    if action == GET_GOOD_NAME:
        search_this_name(update, context, datas["good_name"])


def add_meeting(update, context, id_contact):
    update_value_for_id(id_contact, 26, date.today().strftime("%d %B %Y"))
    context.bot.send_message(chat_id=update.effective_chat.id, text="C'est ajoute pour la date d'aujourd'hui, chef.")


def unknown(update, context):
    context.bot.send_message(chat_id=update.effective_chat.id, text="C'est pas faux.")


def is_allowed_user(username):
    allowed_users = []
    with open("authorized_users.txt", "r") as f:
        for line in f:
            allowed_users.append(line.strip())

    if username not in allowed_users:
        return False

    return True


def get_id_sheet():
    with open("id_sheet.txt", "r") as f:
        return f.read().strip()


def get_line_people(sheet, search):
    return sheet.find(search, in_column=3).row


def get_info_by_id(id_people):
    sheet = client.open_by_key(get_id_sheet()).sheet1
    line = get_line_people_by_id(sheet, id_people)
    return sheet.row_values(line)


def get_line_people_by_id(sheet, search):
    return sheet.find(str(search), in_column=1).row


def beautify_infos(infos):
    for x in range(len(infos), 28):
        infos.append('')
    reseau = infos[1]
    qualite = infos[13]

    output = "*{0}* {1} _{2}_ \n".format(infos[2], infos[5], infos[6])
    if reseau == "Conseil LaREM":
        partSoutien = "`Soutien : {0}, Parainnage : {1}`\n"
        output = output + partSoutien.format(infos[15], infos[16])

    part2 = "-" \
            "\n*Contact* \n{0} (pro) \n{1} (perso) \n{2} \n" \
            "-\n"
    output = output + part2.format(infos[7].replace("_", "\_"), infos[8].replace("_", "\_"), infos[9])

    if qualite in ["Député", "Député européen", "Élus tirés au sort", "Président de département",
                   "Président de groupe", "Président de groupe - Elu", "Président de Région",
                   "Président EPCI", "Sénateur", "Elu"]:
        partQualite = "*{0}* (sensibilite : {1}), Commission {2} ({3}, {4})\n"
        output = output + partQualite.format(infos[13], infos[14], infos[19], infos[20], infos[21])

    part3 = "{0}, {1} ({2}) \n" \
            "-\n" \
            "*Scores* \n`{3}, {4}, {5} ({6})`\n" \
            "-\n" \
            "*Notes* \n{7}\n" \
            "-\n" \
            "*Derniere rencontre* le _{8}_ \n{9}\n"
    output = output + part3.format(
        infos[12], infos[11], infos[10],
        infos[22], infos[23], infos[24], infos[25],
        infos[27],
        infos[26], infos[27])
    return output


def get_info_people(search):
    try:
        sheet = client.open_by_key(get_id_sheet()).sheet1
        line = get_line_people(sheet, search)
        return sheet.row_values(line), None

    except CellNotFound:
        return None, 'Sorry no fucking clue who u talking bout'


SCORE_1 = 22
SCORE_2 = 23
SCORE_3 = 24


def change_score(update, context, datas):
    if "score" in datas:
        context.bot.send_message(chat_id=update.effective_chat.id,
                                 text="Je change ca, chef.")
        updated_infos = update_value_for_id(datas['id_contact'], column=datas['id_score'], value=datas['score'])
        reply_with_infos(update, context, updated_infos)

        return
    if "id_score" in datas:
        keyboard = [[], []]
        for x in range(6):
            keyboard[0].append(InlineKeyboardButton("{0}".format(x), callback_data=json.dumps({
                "a": CHANGE_SCORE,
                "d": {"id_contact": datas['id_contact'], "id_score": datas['id_score'], "score": x}})))

        reply_markup = InlineKeyboardMarkup(keyboard)

        context.bot.send_message(chat_id=update.effective_chat.id, text="Quelle note ?",
                                 reply_markup=reply_markup)
        return

    infos = get_info_by_id(datas['id_contact'])
    keyboard = [[
        InlineKeyboardButton("1: ({0})".format(infos[SCORE_1]), callback_data=json.dumps(
            {"a": CHANGE_SCORE, "d": {"id_contact": infos[0], "id_score": SCORE_1}})),
        InlineKeyboardButton("2: ({0})".format(infos[SCORE_2]), callback_data=json.dumps(
            {"a": CHANGE_SCORE, "d": {"id_contact": infos[0], "id_score": SCORE_2}})),
        InlineKeyboardButton("3: ({0})".format(infos[SCORE_3]), callback_data=json.dumps(
            {"a": CHANGE_SCORE, "d": {"id_contact": infos[0], "id_score": SCORE_3}}))
    ]]

    reply_markup = InlineKeyboardMarkup(keyboard)

    context.bot.send_message(chat_id=update.effective_chat.id, text="Quel score faut il changer ?",
                             reply_markup=reply_markup)


def update_value_for_id(id_people, column, value):
    sheet = client.open_by_key(get_id_sheet()).sheet1
    line = get_line_people_by_id(sheet, id_people)
    sheet.update_cell(line, column + 1, value)
    return sheet.row_values(line)


def get_profile_picture_twitter_url(name):
    return "http://twivatar.glitch.me/" + name


def all_handler(update, context):
    msg = update.message.text
    if not msg.startswith("@TheSauronBot"):
        return
    args = shlex.split(msg)
    if args[1] == "/note":
        change_note(update, context, args[2:])
    return


def change_note(update, context, args):
    if len(args) != 2:
        return
    update_value_for_id(args[0], 25, args[1])
    context.bot.send_message(chat_id=update.effective_chat.id,
                             text="C'est fait, chef.")



# before application was main
def application(environ, start_response):
    logging.basicConfig(level=logging.WARNING,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # updater = Updater(token='973076871:AAFNjr0hjuIQXGqIOxLT86jN02lxmDpiFI4', use_context=True)

    updater = Updater(token=token1, use_context=True)

    dispatcher = updater.dispatcher

    start_handler = CommandHandler('start', start)
    dispatcher.add_handler(start_handler)

    get_handler = CommandHandler('get', get_entry, filters=~Filters.update.edited_message)
    dispatcher.add_handler(get_handler)

    updater.dispatcher.add_handler(CallbackQueryHandler(button))

    unknown_handler = MessageHandler(Filters.command, unknown)
    dispatcher.add_handler(unknown_handler)

    allHandler = MessageHandler(Filters.text, all_handler)
    dispatcher.add_handler(allHandler)

    updater.start_polling()


# if __name__ == "__application__":
#     application()
